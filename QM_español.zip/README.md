Física Matemática II
===============

Este apunte ha sido confeccionado principalmente por [G. Rubilar](https://gfrubi.github.io/), con aportes de Oscar Fuentealba, y usa parte del código LaTeX de los [apuntes](https://bitbucket.org/seanmauch/applied_math) de Sean Mauch).

Esta obra ha sido publicada bajo una [licencia GPL v3](https://github.com/gfrubi/GR/blob/master/LICENSE).

Puede descargar el archivo pdf compilado directamente desde [aquí](https://github.com/gfrubi/FM2/raw/master/FM2.pdf), o verlo en línea usando Google Drive siguiendo [este link](https://drive.google.com/viewer?url=https://github.com/gfrubi/FM2/raw/master/FM2.pdf).


Otros apuntes en https://github.com/gfrubi
